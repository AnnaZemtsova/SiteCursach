<?php 
    ?>
             <div class="footer"></div>    
             <div class="header">
                 <div class="logo">
                    <img  width=90px
                          height= 90px      
                         src="https://img-fotki.yandex.ru/get/55/200418627.32/0_110475_59920db5_orig.png"> 
                </div>
                 <div  class="registration" >
                       <div class="escape"> Выйти</div>
                      <div  class="enter"> Войти</div>
                      <div class="reg">Зарегестрироваться</div>
                 </div>
              </div>
             <script type="text/javascript" src="http://localhost/SiteCursach/assets/slider.js"></script>
             <script type="text/javascript" src="http://localhost/SiteCursach/assets/test.js"></script>  
       <?php     
?>