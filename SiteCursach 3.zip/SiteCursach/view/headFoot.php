<?php
?>
<HTML>
<HEAD>
   <meta charset=UTF-8>
        <link href="http://localhost/SiteCursach/assets/styleHome.css" rel="stylesheet"> 
              <script src="http://code.jquery.com/jquery-latest.min.js"></script>
            <!-- <script  src="../_js/jquery-ui.min.js">
        </script>-->
         </HEAD>
   
         <BODY>
              <div class="header">
                    <div class="logo">
                    <img  width=90px
                    height= 90px      src="https://img-fotki.yandex.ru/get/55/200418627.32/0_110475_59920db5_orig.png"> 
                    </div>
                   <div class="title">
                    НОВОСТИ ИНТЕРЬЕРА
                  </div>
                </div> 
             <div class="boxContent">
             <div class="box">
                 <div class="home"><a href="?page=home">
                 HOME</a></div>
                 <div class="news_contacts" ><a href="?page=categories">NEWS </a>
                    <ul class="menu"> 
                        <li>
                          <ul class="submenu">
                              <li> <a href="?page=allNews">Все новости</a>
                          </li>
                          <li> <a href="?page=categories">Новости по категориям</a>
                          </li>
                          <li><a href="?page=category">Пользователи</a> 
                          </li>
                     </ul></li>
                      </ul>
                   </div>  
                 <div class="news_contacts"><a href="?page=contacts">
                     CONTACTS</a></div> 
              </div>               
            </div>
             <div class="footer"></div>    
             <div class="header">
                 <div class="logo">
                    <img  width=90px
                          height= 90px      
                         src="https://img-fotki.yandex.ru/get/55/200418627.32/0_110475_59920db5_orig.png"> 
                </div>
                 <div  class="registration" >
                      <div class="enter"> Войти</div>
                      <div class="reg">Зарегестрироваться</div>
                 </div>
              </div>
             <script type="text/javascript" src="http://localhost/SiteCursach/assets/slider.js"></script>
             <script type="text/javascript" src="http://localhost/SiteCursach/assets/test.js"></script>  
        <script type="text/javascript" src="http://localhost/SiteCursach/assets/move.js"></script>
                 
   </BODY>
</HTML>
       <?php          ?>