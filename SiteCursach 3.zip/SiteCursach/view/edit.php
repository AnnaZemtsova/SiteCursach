<?php
     require_once("/Applications/XAMPP/xamppfiles/htdocs/SiteCursach/view/header.php");
?>
        <link href="http://localhost/SiteCursach/assets/styleHome.css" rel="stylesheet"> 
        <link href="http://localhost/SiteCursach/assets/user.css" rel="stylesheet"> 
        <link href="http://localhost/SiteCursach/assets/editUser.css" rel="stylesheet"> 
     <link href="http://localhost/SiteCursach/assets/edit.css" rel="stylesheet"> 
    <form method="GET" action="/SiteCursach/models/edit.php">
         <input class="avatar" name = "avatar" placeholder="Введите адрес к фото">          
            <div class="textNear">
            <p style="color:white;font-size:25"><font>
                <input type="text" name="id" class="unsean" value="<?php echo $_REQUEST['id']?>">
                <input type="text" name="name" class="inputName" placeholder="Введите Имя">
                <input type="text" name="surname" class="inputName" placeholder="Введите Фамилию">
                <input type="text" name="email" class="inputName" placeholder="Введите email"><br>
                <input type="text" name="login" class="inputName" placeholder="Введите Логин"><br>
                <p style="margin-top:85px;color:orange;font-size:25;text-align:center">Описание</p><br>
                <input type="text" class="description" placeholder="Описание" name="description"> 
               <br>
                <a href ="?page=add"><input type="submit" value="OK" class="button"></a>
                </font></p><br>         
         </div>
    </form>
<?php
     require_once("/Applications/XAMPP/xamppfiles/htdocs/SiteCursach/routing.php");
     require_once("/Applications/XAMPP/xamppfiles/htdocs/SiteCursach/view/footer.php");
?>