<?php
     header("Location: /SiteCursach/routing.php?page=home");
?>