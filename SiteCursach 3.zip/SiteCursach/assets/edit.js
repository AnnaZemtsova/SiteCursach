var ID;
jQuery(".img").click(function(){
    ID = this.getAttribute("idUser");
    console.log(ID);
    window.location.href = 'http://localhost/SiteCursach/routing.php?page=edit&id='+ID;
}); 