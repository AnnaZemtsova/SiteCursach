
/*jQuery(".home").click(function(){
    window.location.href = "http://localhost/SiteCursach/view/layout.php";
});
jQuery(".submenu li").eq(0).click(function(){
 window.location.href = "http://localhost/SiteCursach/view/categories.php";
});
jQuery(".submenu li").eq(1).click(function(){
   window.location.href = "http://localhost/SiteCursach/view/layout.php";
});*/