/*$(".image").eq(0).mouseover(function(){
   $(".text").eq(0).css({
       display:'block'
   }) ;
});
$(".image").eq(0).mouseout(function(){
   $(".text").eq(0).css({
       display:'none'
   }) ;
});

$(".image").eq(1).mouseover(function(){
   $(".text").eq(1).css({
       display:'block'
   }) ;
});
$(".image").eq(1).mouseout(function(){
   $(".text").eq(1).css({
       display:'none'
   }) ;
});

$(".image").eq(2).mouseover(function(){
   $(".text").eq(2).css({
       display:'block'
   }) ;
});
$(".image").eq(2).mouseout(function(){
   $(".text").eq(2).css({
       display:'none'
   }) ;
});

$(".image").eq(3).mouseover(function(){
   $(".text").eq(3).css({
       display:'block'
   }) ;
});
$(".image").eq(3).mouseout(function(){
   $(".text").eq(3).css({
       display:'none'
   }) ;
});

$(".image").eq(4).mouseover(function(){
   $(".text").eq(4).css({
       display:'block'
   }) ;
});
$(".image").eq(4).mouseout(function(){
   $(".text").eq(4).css({
       display:'none'
   }) ;
});

$(".image").eq(5).mouseover(function(){
   $(".text").eq(5).css({
       display:'block'
   }) ;
});
$(".image").eq(5).mouseout(function(){
   $(".text").eq(5).css({
       display:'none'
   }) ;
});

$(".image").eq(6).mouseover(function(){
   $(".text").eq(6).css({
       display:'block'
   }) ;
});
$(".image").eq(6).mouseout(function(){
   $(".text").eq(6).css({
       display:'none'
   }) ;
});

$(".image").eq(7).mouseover(function(){
   $(".text").eq(7).css({
       display:'block'
   }) ;
});
$(".image").eq(7).mouseout(function(){
   $(".text").eq(7).css({
       display:'none'
   }) ;
});

$(".image").eq(8).mouseover(function(){
   $(".text").eq(8).css({
       display:'block'
   }) ;
});
$(".image").eq(8).mouseout(function(){
   $(".text").eq(8).css({
       display:'none'
   }) ;
});
*/