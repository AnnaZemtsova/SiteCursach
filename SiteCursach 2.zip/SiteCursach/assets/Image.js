/*function slide(j){
    var items=$(".image").eq(0).find('.imag');
    items.hide();
    var items=$(".slider");
    items.hide();
    var items=$(".image").eq(0).find('.imag').eq(j);
    items.width(0).height(0);
    items.css({
        "margin-top":"25%"
    });
     items.animate({
        'width':'1000px',
        'height':'100%',
        "margin-top":"0%"
     },3000); 
    var items=$(".slider");
    items.animate({
        "margin-top":"-90px"
    },1000);
}

$(".circle").eq(0).click(function(){
    slide(2);
});

$(".circle").eq(1).click(function(){
    slide(4);
});

$(".circle").eq(2).click(function(){
    slide(6);
});

$(".circle").eq(3).click(function(){
    slide(8);
});

$(".circle").eq(4).click(function(){
    slide(9);
});*/