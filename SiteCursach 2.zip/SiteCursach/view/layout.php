<?php
     require_once("/Applications/XAMPP/xamppfiles/htdocs/SiteCursach/view/header.php");
?>      
        <link href="http://localhost/SiteCursach/assets/styleHome.css" rel="stylesheet">          
    
             <center>
                     <div id="slider" >    
                     <div class="leftArrow" ><img src="http://localhost/SiteCursach/assets/left.png">
                         </div>
                         <div class="slide">
                         <img  height=100% width="1000px"    src="http://www.weareart.ru/public/uploads/news/1560/b-IMG_aad1edcf19f9.jpg"></div>
                         <div class=" slide"><img  height=100% width="1000px"   src="http://anywalls.com/pic/201211/1366x768/anywalls.com-49208.jpg"> </div>
                         <div class=" slide"><img  height=100% width="1000px"   src="http://mir29.ru/web/files/logotypes/1439137954790/1439181593.jpg"> </div>
                         <div class="active slide"><img  height=100% width="1000px"   src="http://ujew.com.ua/files/userpics/imagecache/221x221/kreativniy-divan-12.jpg"></div> 
                         <div class=" slide"><img  height=100% width="1000px"   src="http://www.lida-anton.ru/sites/default/files/1-8.jpg"> </div> 
                         <div class=" slide"><img  height=100% width="1000px"  src="http://remraion.ru/images/com_rrgallery/original/e1efa2844a3bf28d4cd798703e1d63b0.jpg"> </div> 
                         <div class=" slide"><img  height=100% width="1000px"  src="http://remraion.ru/images/com_rrgallery/original/acad8b42b2258b28337f3b38d56949ad.jpg"></div>  
                         <div class="  slide"><img  height=100% width="1000px"  src="http://www.stroypark.su/upload/news/AvangardNumbers.jpg"> </div> 
                         <div class=" slide"><img  height=100% width="1000px"  src="http://www.cs-decor.ru/d/765001/d/02_3.jpg"> </div> 
                         <div class=" slide"><img  height=100% width="1000px"  src="http://ujew.com.ua/files/userpics/imagecache/221x221/kreativniy-divan-12.jpg">  </div> 
                         
                  <div class="rightArrow"><img src="http://localhost/SiteCursach/assets/right.png">
                         </div>
                    </div>
                 <div class="slideCircle">
                             <div class="outCircle"><div class ="circle"></div></div>
                             <div class="outCircle"><div class ="circle"></div></div>
                             <div class="outCircle"><div class ="circle"></div></div>
                             <div class="outCircle"><div class ="circle"></div></div>
                             <div class="outCircle"><div class ="circle"></div></div>
                         </div>
             </center>
             
             
                          
             <!--  <div class="arrow right"></div>
             </div>-->
   <!--///////////////*/ ПОД КАРТИНКОЙ LEFT-->
        
              <div  class="underImRight">
                  <p class="innerTitle">Особенности современного дизайна</p>

                  <div >
                      <img class="innerImageLeft"  src="http://www.weareart.ru/public/uploads/news/1560/b-IMG_aad1edcf19f9.jpg">
                  </div>
                  <p>Диза́йн интерье́ра (интерье́рный диза́йн) — отрасль дизайна,
                      направленная на интерьер помещений с целью обеспечить удобство и эстетически приятное взаимодействие среды с людьми. 
                      Интерьерный дизайн сочетает в себе художественный и промышленный дизайн. Дизайнер выполняет оптимизацию труда в помещении, 
                      улучшает навигацию в крупных помещениях, разрабатывает оформление специализированных помещений (например, студий звукозаписи, 
                      киномонтажа, фотографии; аквапарков) согласно требованиям клиентов. Дизайнер управляет всем процессом оформления интерьера, начиная планировкой помещения, освещения, систем вентиляции, акустикой; 
                      отделкой стен; и заканчивая размещением мебели и установкой 
                      навигационных знаков.</p>
                      <img  class="innerImageRight" src="http://4.bp.blogspot.com/-yFQYbuQb0-U/VQKGefp7fqI/AAAAAAAAVI4/ycF5T0MqF38/s1600/современный-интерьер-квартиры-Plasterlina%2B(12).jpg">
                      <p>Разработка дизайна интерьера начинается с составления дизайн-проекта — комплекта документов, описывающих функциональные и дизайнерские решения, в них содержатся чертежи помещения и описания всех деталей будущего интерьера, включая отделочные материалы и расположение коммуникаций. В проекте присутствует техническое задание, в котором описаны все требования и пожелания заказчика.

Сначала производятся обмеры помещения, после 
                          чего разрабатываются примерные планировочные решения и эскизы. 
                          На этом этапе дизайнер предлагает заказчику несколько вариантов планировки с распределением основных функциональных зон и расстановкой мебели. Так как 3D-моделирование — трудозатратный процесс, на этапе примерного планирования подробные трёхмерные модели разрабатываются только после согласования с заказчиком.

После утверждения размещения зон разрабатываются
                          проектировочные чертежи электрических проводов и планируется расположение электроприборов (освещение, электрический обогрев и прочее); в случае необходимости выполняются чертежи изменений в планировке; план потолков и напольных покрытий, размещения сантехнического оборудования, ведомости, содержащие сведения об отделке и заказываемых материалах и предметах мебели и декоре.

Следующим этапом является реализация запланированных работ;
                          на этой стадии дизайнер контролирует работу отделочных и ремонтных бригад, предоставляя заказчику требуемую сметную документацию.

                          Состав и правила оформления рабочих чертежей 
                          архитектурных решений интерьеров производственных и вспомогательных здании всех отраслей промышленности и народного хозяйства установлены ГОСТ 21.507-81* СПДС. Интерьеры. Рабочие чертежи.</p>
            
        <iframe width="420" height="310" 
src="https://www.youtube.com/embed/yII05fNPKgs"> 
</iframe>
              </div>
 
   <!--///////////////*/ ПОД КАРТИНКОЙ RIGHT--> 
             
              <div class="innerLeft">               
                  <p class="innerTitleLeft">ТОП-10 НОВОСТЕЙ</p>
                  <div class="block">
                     <div>
                        <img class="image" src="http://poltava-obl.ru/novosti/wp-content/uploads/2013/09/dizain.jpg">
                         <p class="text">Компания Energy-Systems профессионально занимается проектированием архитектуры, дизайна и инженерии жилых, общественных, коммерческих и производственных объектов. 
                         </p>
                     </div>
                 </div>
                  <div class="block">
                     <div>
                        <img class="image" src="http://avivas.ru/img/news/201210/59317002208.jpeg">
                         <p class="text">Компания Energy-Systems профессионально занимается проектированием архитектуры, дизайна и инженерии жилых, общественных, коммерческих и производственных объектов. 
                         </p>
                     </div>
                 </div>
                  <div class="block">
                     <div>
                        <img class="image" src="http://интерьер-галерея.рф/d/769591/d/Современные_интерьеры_с_акцентами_из_натуральной_древесины,_деревянные_акценты_из_дерева_в_интерьере,_дерево_в_современно_22.jpg">
                         <p class="text">Компания Energy-Systems профессионально занимается проектированием архитектуры, дизайна и инженерии жилых, общественных, коммерческих и производственных объектов. 
                         </p>
                     </div>
                 </div>
                  <div class="block">
                     <div>
                        <img class="image" src="http://nua.in.ua/wp-content/uploads/2016/02/modulnye-kartiny-03.jpg">
                         <p class="text">Компания Energy-Systems профессионально занимается проектированием архитектуры, дизайна и инженерии жилых, общественных, коммерческих и производственных объектов. 
                         </p>
                     </div>
                 </div>
                  <div class="block">
                     <div>
                        <img class="image" src="http://site-88281.mozfiles.com/files/88281/001.jpg">
                         <p class="text">Компания Energy-Systems профессионально занимается проектированием архитектуры, дизайна и инженерии жилых, общественных, коммерческих и производственных объектов. 
                         </p>
                     </div>
                 </div>
                  <div class="block">
                     <div>
                        <img class="image" src="http://mebelshop.com/blog/wp-content/uploads/2012/09/wpid-Svetloe-buduschee-0.jpg">
                         <p class="text">Компания Energy-Systems профессионально занимается проектированием архитектуры, дизайна и инженерии жилых, общественных, коммерческих и производственных объектов. 
                         </p>
                     </div>
                 </div>
                  <div class="block">
                     <div>
                        <img class="image" src="https://cdn.riastatic.com/photos/ria/dom_news_logo/20/2091/209133/209133fl.jpg?v=1474995356">
                         <p class="text">Компания Energy-Systems профессионально занимается проектированием архитектуры, дизайна и инженерии жилых, общественных, коммерческих и производственных объектов. 
                         </p>
                     </div>
                 </div>
                  <div class="block">
                     <div>
                        <img class="image" src="http://интерьер-галерея.рф/d/769591/t/v6/images/head_pic.jpg">
                         <p class="text">Компания Energy-Systems профессионально занимается проектированием архитектуры, дизайна и инженерии жилых, общественных, коммерческих и производственных объектов. 
                         </p>
                     </div>
                 </div>
                  <div class="block">
                     <div>
                        <img class="image" src="http://hronika.info/uploads/posts/2016-06/thumbs/1464939374_mebel.jpeg">
                         <p class="text">Компания Energy-Systems профессионально занимается проектированием архитектуры, дизайна и инженерии жилых, общественных, коммерческих и производственных объектов. 
                         </p>
                     </div>
                 </div>
                  <div class="block">
                     <div>
                        <img class="image" src="http://vnews.agency/uploads/posts/2016-02/1454320638_yarkiy-akcent.jpg">
                         <p class="text">Компания Energy-Systems профессионально занимается проектированием архитектуры, дизайна и инженерии жилых, общественных, коммерческих и производственных объектов. 
                         </p>
                     </div>
                 </div>
                  <div class="block">
                     <div>
                        <img class="image" src="http://www.3dray.ru/News/ivi_chair/design_chair_1.jpg">
                         <p class="text">Компания Energy-Systems профессионально занимается проектированием архитектуры, дизайна и инженерии жилых, общественных, коммерческих и производственных объектов. 
                         </p>
                     </div>
                 </div>
                  
             </div> 
<script type="text/javascript" src="http://localhost/SiteCursach/assets/slider.js"></script>
             <script type="text/javascript" src="http://localhost/SiteCursach/assets/test.js"></script>  
<?php

     require_once("/Applications/XAMPP/xamppfiles/htdocs/SiteCursach/view/footer.php");
     require_once('/Applications/XAMPP/xamppfiles/htdocs/SiteCursach/routing.php');
?>