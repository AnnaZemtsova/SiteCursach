<?php
     require_once("/Applications/XAMPP/xamppfiles/htdocs/SiteCursach/view/header.php");
?>
 <link href="http://localhost/SiteCursach/assets/styleHome.css" rel="stylesheet">
 <link href="http://localhost/SiteCursach/assets/categories.css" rel="stylesheet">
             <a href ="?page=categories1"><div class="block">
                 <img class="image" style= "background-image:url(http://syndyk.by/sites/syndyk/img/photoreportage/20667/760x570/image-194728.jpg);">
                 <div class="text">Авангард в интерьере</div>
             </div></a>
             <a href ="?page=categories2"><div class="block">
                 <img class="image" style= "background-image:url(http://cugij.com/wp-content/uploads/2013/10/гостинная.jpeg);">
                 <div class="text">Авангард в интерьере</div>
             </div>
             <a href ="?page=categories3"><div class="block">
                 <img class="image" style= "background-image:url(http://img1.liveinternet.ru/images/attach/c/11/115/38/115038315_gostin.jpg)">
                 <div class="text">Авангард в интерьере</div>
             </div>
              <a href ="?page=categories4"><div class="block">
                 <img class="image" style= "background-image:url(http://foto-designa.ru/_pu/0/27666057.jpg)">
                  <div class="text">Авангард в интерьере</div>
             </div>
              <a href ="?page=categories5"><div class="block">
                 <img class="image" style= "background-image:url(http://foto-designa.ru/_pu/0/41024931.jpg)">
                  <div class="text">Авангард в интерьере</div>
             </div>
              <a href ="?page=categories6"><div class="block">
                 <img class="image" style= "background-image:url(http://4backyard.ru/interior/photo109.jpg)"
                      >
                  <div class="text">Авангард в интерьере</div>
             </div>
              <a href ="?page=categories7"><div class="block">
                 <img class="image" style= "background-image:url(http://www.kiryushkin.ru/img/p01_2417.jpg)">
                  <div class="text">Авангард в интерьере</div>
             </div>
              <a href ="?page=categories8"><div class="block">
                 <img class="image" style= "background-image:url(http://uhouse.ru/uploads/gallery/main/1306/02.jpg)">
                  <div class="text">Авангард в интерьере</div>
             </div>
              <a href ="?page=categories9"><div class="block">
                 <img class="image" style= "background-image:url(http://www.remontbp.com/wp-content/uploads/6355.jpg)">
                  <div class="text">Авангард в интерьере</div>
             </div>
 
             <script type="text/javascript" src="http://localhost/SiteCursach/assets/slider.js"></script>
             <script type="text/javascript" src="http://localhost/SiteCursach/assets/test.js"></script>  
            <script type="text/javascript" src="http://localhost/SiteCursach/assets/move.js"></script>  
            <script type="text/javascript" src="http://localhost/SiteCursach/assets/categories.js"></script>
<?php               
     require_once("/Applications/XAMPP/xamppfiles/htdocs/SiteCursach/view/footer.php");
     require_once('/Applications/XAMPP/xamppfiles/htdocs/SiteCursach/routing.php');
?>